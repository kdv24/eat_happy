Theme by worthapost.

--INSTALL
After installing the theme make sure you visit theme setting (admin/build/themes/settings/admire_grunge) page to setup your RSS feed. By default it points to Drupal's default.

Please rate this theme on our website. This help us understand you better. 


--PREMIUM THEMES
Visit http://www.worthapost.com/ to see our high profile themes.


